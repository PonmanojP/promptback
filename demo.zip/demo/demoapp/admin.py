from django.contrib import admin
from .models import DashboardChart,PDFFile

admin.site.register(DashboardChart)
admin.site.register(PDFFile)
